<?php  


echo "<pre>";
print_r($_POST);
//print_r($_GET);

echo "</pre>";

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
</head>
<body>
<?php //echo "<p>Bonjour ".$_POST['lastname']."</p>"; ?>	
</body>
</html>